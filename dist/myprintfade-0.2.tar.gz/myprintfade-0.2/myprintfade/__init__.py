from .animation import print_fade
